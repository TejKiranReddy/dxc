package com.dxcass.user.dao;

import com.dxcass.user.model.User;

public interface UserDAO {
	boolean validate = false;

	public   boolean validate(User user);
	

}
