package com.dxcass.user.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dxcass.user.dbcon.DBConnection;
import com.dxcass.user.model.Training;
import java.sql.PreparedStatement;

import java.sql.Connection;


public class TrainingDAOImpl implements TrainingDAO {
	int percentage;
	Scanner sc=new Scanner(System.in);
	Connection connection = DBConnection.getConnection();
	private static final String FETCH_USERS_ALL = "select * from trainings";
	private static final String UPDATE_USER = "Update training set sapId=?,employeeName=?,stream=?,percentage=?";

	public List<Training> getAllRecords() {
		// TODO Auto-generated method stub
		List<Training> getAllRecords = new ArrayList<Training>();
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(FETCH_USERS_ALL);
			while (resultSet.next()) {
				Training training = new Training(0, null, null, 0);
				training.setSapId(resultSet.getInt(1));
				training.setEmployeeName(resultSet.getString(2));
				training.setStream(resultSet.getString(3));
				training.setPercentage(resultSet.getInt(4));
				getAllRecords.add(training);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return getAllRecords;
	}
	public void updatePercentage() {
		// TODO Auto-generated method stub
		try {
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(FETCH_USERS_ALL);
			PreparedStatement preparedStatement;
			while(resultSet.next()) {
				System.out.println("SapId: "+resultSet.getString(1));
				System.out.println("Employee Name: "+resultSet.getString(2));
				System.out.println("Stream: "+resultSet.getString(3));
				if(resultSet.getInt(4)==0) {
					System.out.println("Enter the Percentage");
					percentage=sc.nextInt();
					preparedStatement=connection.prepareStatement(UPDATE_USER);
					preparedStatement.setInt(1, percentage);
					preparedStatement.setString(2,resultSet.getString(1));
					preparedStatement.executeUpdate();
				}
				else {
					System.out.println("Percentage: "+resultSet.getInt(4));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
