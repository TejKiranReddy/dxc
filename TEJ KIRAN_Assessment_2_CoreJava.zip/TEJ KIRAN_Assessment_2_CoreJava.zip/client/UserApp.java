package com.dxcass.user.client;

import java.util.Scanner;

import com.dxcass.user.dao.UserDAO;
import com.dxcass.user.dao.UserDAOImpl;
import com.dxcass.user.model.User;

public class UserApp {

	
		Scanner scanner=new Scanner(System.in);
		User user;
		UserDAO userDAO = new UserDAOImpl();
		String userName;
		String password;
		
		
		int choice=0;

		public UserApp() {
			// TODO Auto-generated constructor stub
			this.userDAO=new UserDAOImpl();
		}
		public void validate() {
			System.out.println("Enter Username and password");
			userName=scanner.next();
			password=scanner.next();
			
			User user1=new User(userName, password);
			if(userDAO.validate(user1))
			{
				System.out.println("login successful");
				
			}
			else 
				System.out.println("incorrect details");
			
		}
}	