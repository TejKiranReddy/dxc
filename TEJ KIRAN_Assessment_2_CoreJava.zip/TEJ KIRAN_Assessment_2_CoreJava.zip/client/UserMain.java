package com.dxcass.user.client;

public class UserMain {

	  public static void main(String[] args) {
		  UserApp app=new UserApp();
		  app.validate();
	       
		
	}
	       
	 
	    }

