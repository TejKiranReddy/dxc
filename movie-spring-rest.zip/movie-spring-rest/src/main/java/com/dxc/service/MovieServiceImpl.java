package com.dxc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.dao.MovieDAO;
import com.dxc.model.Movie;
@Service
public class MovieServiceImpl implements MovieService {
	@Autowired
	MovieDAO moviee;

	@Override
	public boolean addMovie(Movie movie) {
		// TODO Auto-generated method stub
		
		return moviee.addMovie(movie);
	}

	@Override
	public List<Movie> getallMovies() {
		// TODO Auto-generated method stub
		return moviee.getallMovies();
	}

	@Override
	public Movie getMovie(int ticketId) {
		// TODO Auto-generated method stub
		return moviee.getMovie(ticketId);
	}

	@Override
	public boolean deleteMovie(int ticketId) {
		// TODO Auto-generated method stub
		return moviee.deleteMovie(ticketId);
	}

	@Override
	public boolean updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		return moviee.updateMovie(movie);
	}

}
