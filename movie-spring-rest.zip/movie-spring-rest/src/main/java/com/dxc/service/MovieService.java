package com.dxc.service;

import java.util.List;

import com.dxc.model.Movie;

public interface MovieService {
	public boolean addMovie(Movie movie);
	public List<Movie> getallMovies();
	public Movie getMovie(int ticketId);
	public boolean deleteMovie(int ticketId);
	public boolean updateMovie(Movie movie);
	
	

}
