package com.dxc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.dxc.model.Movie;

@Repository

public class MovieDAOImpl implements MovieDAO {
	@Autowired
	MongoTemplate t;

	@Override
	public boolean addMovie(Movie movie) {
		// TODO Auto-generated method stub
		t.save(movie);
		return false;
	}

	@Override
	public List<Movie> getallMovies() {
		// TODO Auto-generated method stub
		
		return t.findAll(Movie.class);
	}

	@Override
	public Movie getMovie(int ticketId) {
		// TODO Auto-generated method stub
		return t.findById(ticketId, Movie.class,"movie");
	}

	@Override
	public boolean deleteMovie(int ticketId) {
		// TODO Auto-generated method stub
		Movie deleteMovie=getMovie(ticketId);
		t.remove(deleteMovie);
		return false;
	}

	@Override
	public boolean updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		t.save(movie);
		return false;
	}

}
