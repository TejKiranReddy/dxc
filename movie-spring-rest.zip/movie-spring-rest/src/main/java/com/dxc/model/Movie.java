package com.dxc.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document
public class Movie {
	@Id
	private int ticketId;
	private String movieName;
	private String location;
	private int budget;
	public Movie() {
		// TODO Auto-generated constructor stub
	}
	public int getticketId() {
		return ticketId;
	}
	
	public void setticketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getlocation() {
		return location;
	}
	public void setlocation(String location) {
		this.location = location;
	}
	public int getBudget() {
		return budget;
	}
	public void setBudget(int budget) {
		this.budget = budget;
	}
	public Movie(int ticketId, String movieName, String location, int budget) {
		super();
		this.ticketId = ticketId;
		this.movieName = movieName;
		this.location = location;
		this.budget = budget;
	}
	@Override
	public String toString() {
		return "Movie [movieTicketPrice=" + ticketId + ", movieName=" + movieName + ", location=" + location
				+ ", budget=" + budget + "]";
	}
	

}
