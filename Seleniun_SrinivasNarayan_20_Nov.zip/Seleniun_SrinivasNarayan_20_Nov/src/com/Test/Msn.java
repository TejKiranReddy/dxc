package com.Test;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
@Test
public class Msn {
	public  WebDriver driver;
	public String Browser="chrome";

	
	public void testcase1() throws IOException, InterruptedException, AWTException{
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		driver.get("https://www.msn.com/en-in");
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//click on onenote
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		//Tab window
		Set<String> allids = driver.getWindowHandles();
		Iterator<String> it=allids.iterator();
		String mid=it.next();
		String t1=it.next();
		driver.switchTo().window(t1);
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("7382991997");
		Thread.sleep(3000);
		//close tab window
		driver.close();
		//switch to main window reference
		driver.switchTo().window(mid);
		Thread.sleep(3000);
		//click on skype in mainpage
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		driver.close();
	}

}
