import React from 'react';

import './App.css';
import ListProductComponent from './components/ListProductComponent';
import ProductComponent from './components/ProductComponent';
import {Switch,Route} from 'react-router-dom';

import {BrowserRouter as Router} from 'react-router-dom';
import SearchComponent from './components/SearchComponent';
import DisplayComponent from './components/DisplayComponent';


function App() {
  return (
    <div className="App">
    <h1>Product App</h1>
     <Router>
       <Switch>
      <Route exact path="/" component={ListProductComponent}></Route>
      <Route exact path="/products" component={ListProductComponent}></Route>
     
      <Route exact path="/products/:prodId" component={ProductComponent}></Route>
      <Route  exact path="/productsearch" component={SearchComponent}></Route>
        <Route path="/productSearch/:prodName" component={DisplayComponent}></Route>
      
     
      
      </Switch>
     </Router>
    </div>
  );
}

export default App;
