package com.dxc.jsp.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dxc.jsp.model.Question;

/**
 * Servlet implementation class FinalServlet
 */
public class FinalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int marks=0;
	String answer3;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinalServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Question> allQuestions = new ArrayList<Question>();
		
		HttpSession session=request.getSession();
	
		answer3=request.getParameter("answer3");
		session.setAttribute("answer3",answer3);
		
		
		String ans1=(String) session.getAttribute("ans1");
		String ans2=(String) session.getAttribute("ans2");
		String ans3=(String) session.getAttribute("ans3");
		
		String answ1=(String) session.getAttribute("answer1");
		String answ2=(String) session.getAttribute("answer2");
		String answ3=(String) session.getAttribute("answer3");
		
		System.out.println("ans1"+ans1);
		System.out.println("correct ans1:"+answ1);
		
		if(ans1.equals(answ1))
			marks=marks+100;
		if(ans2.equals(answ2))
			marks=marks+100;
		if(ans3.equals(answ3))
			marks=marks+100;
		
		response.getWriter().println("The total score is :" +marks);
		
		
		
		
		
		
		
		
	}

}
