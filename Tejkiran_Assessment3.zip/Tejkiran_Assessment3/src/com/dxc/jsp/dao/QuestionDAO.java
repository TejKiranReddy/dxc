package com.dxc.jsp.dao;
import java.util.List;

import com.dxc.jsp.model.*;
public interface QuestionDAO {

	public List<Question>getAllQuestions();
	public boolean validate();
	
}
