package com.dxc.jsp.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc.jsp.dbcon.DBConnection;
import com.dxc.jsp.model.Question;


public class QuestionDAOImpl implements QuestionDAO {
	private static final String FETCH_QUESTIONS = "select * from exam order by RAND() limit 1";
	private static final String CHECK_ANSWER = "select * from exam where question=? and answer=?";
	private Question question=new Question();
	Connection connection = DBConnection.getConnection();
	public QuestionDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Question> getAllQuestions() {
		
			List<Question> allQuestions = new ArrayList<Question>();
			try {
				Statement stat = connection.createStatement();
				ResultSet res = stat.executeQuery(FETCH_QUESTIONS);
			// TODO Auto-generated method stub
				while(res.next()) {
					Question question = new Question();
					question.setQuestionNo(res.getInt(1));
					question.setQuestion(res.getString(2));
					question.setAnswer(res.getString(3));
					
					allQuestions.add(question);

				}
			} catch (SQLException e) {
				e.printStackTrace();
			}		
			return allQuestions;
		}
		
	
	@Override
	public boolean validate() {
		// TODO Auto-generated method stub
		return false;
	}

}
